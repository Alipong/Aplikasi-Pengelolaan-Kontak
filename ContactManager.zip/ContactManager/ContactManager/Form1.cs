﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace ContactManager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Validasi input
            if (string.IsNullOrWhiteSpace(txtNama.Text) ||
                string.IsNullOrWhiteSpace(txtHP.Text) ||
                string.IsNullOrWhiteSpace(txtEmail.Text) ||
                (!rbFriend.Checked && !rbFamily.Checked && !rbColleague.Checked))
            {
                MessageBox.Show("Semua field harus diisi, dan kategori harus dipilih!");
                return;
            }

            if (!long.TryParse(txtHP.Text, out _))
            {
                MessageBox.Show("Nomor telepon harus berupa angka!");
                return;
            }

            // Menentukan kategori
            string category = rbFriend.Checked ? "Teman" :
                              rbFamily.Checked ? "Keluarga" : "Kolega";

            // Membuat objek Contact
            Contact newContact = new Contact(txtNama.Text, txtHP.Text, txtEmail.Text, category);

            // Menambahkan kontak ke ListBox
            listBoxContacts.Items.Add(newContact);

            // Reset input
            txtNama.Clear();
            txtHP.Clear();
            txtEmail.Clear();
            rbFriend.Checked = false;
            rbFamily.Checked = false;
            rbColleague.Checked = false;
        }

        private void listBoxContacts_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
