﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactManager
{
    public class Contact
    {
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Category { get; set; }

        public Contact(string name, string phone, string email, string category)
        {
            Name = name;
            Phone = phone;
            Email = email;
            Category = category;
        }

        public override string ToString()
        {
            return $"{Name} - {Phone} - {Email} - {Category}";
        }
    }
}
